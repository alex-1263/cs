DB_CONFIG = {
    'host': '47.120.14.134',
    'user': 'alex',
    'password': '123456',
    'database': 'ssmsdb'
}
